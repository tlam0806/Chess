#include "move.hpp"
#include "position.hpp"
#include "search_types.hpp"
#include "searchers/strict/heuristic_searcher_v15.hpp"

#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace {

struct Case {
    int depth = 0;
    int position = 0;
    std::string position_id;
    std::string fen;
    int root_score = 0;
    std::string reference_move;
    std::string alternate_move;
    std::string versions;
};

std::vector<std::string> split_tabs(const std::string& line) {
    std::vector<std::string> fields;
    std::istringstream input(line);
    std::string field;
    while (std::getline(input, field, '\t')) {
        fields.push_back(field);
    }
    return fields;
}

chess::Move find_move(const chess::Position& pos, std::string_view uci) {
    chess::MoveList moves;
    chess::generate_legal_moves(pos, moves);
    for (chess::Move move : moves) {
        if (chess::move_to_string(move) == uci) {
            return move;
        }
    }
    throw std::runtime_error("move is not legal: " + std::string(uci));
}

int parent_score_from_child(int child_score) {
    constexpr int MateThreshold = chess::CheckmateScore - 1024;
    if (child_score >= MateThreshold) {
        return -child_score + 1;
    }
    if (child_score <= -MateThreshold) {
        return -child_score - 1;
    }
    return -child_score;
}

int force_move_score(const chess::Position& root, std::string_view uci, int depth) {
    if (depth < 1) {
        throw std::runtime_error("root depth must be at least one");
    }
    chess::Position child = root;
    child.make_move(find_move(root, uci));
    chess::HeuristicSearcherV15 fresh_searcher(64);
    const chess::SearchResult result = fresh_searcher.search_best_move(child, depth - 1);
    if (result.stopped || result.depth != depth - 1) {
        throw std::runtime_error("fresh child search did not complete requested depth");
    }
    return parent_score_from_child(result.score);
}

Case parse_case(const std::string& line) {
    const std::vector<std::string> fields = split_tabs(line);
    if (fields.size() != 8) {
        throw std::runtime_error("expected 8 tab-separated fields");
    }
    return Case{
        std::stoi(fields[0]), std::stoi(fields[1]), fields[2], fields[3],
        std::stoi(fields[4]), fields[5], fields[6], fields[7]
    };
}

} // namespace

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: strict_v3_move_tie_verifier CASES.tsv\n";
        return 64;
    }
    std::ifstream input(argv[1]);
    if (!input) {
        throw std::runtime_error("cannot open cases file");
    }
    std::string line;
    if (!std::getline(input, line) || line != "depth\tposition\tposition_id\tfen\troot_score\treference_move\talternate_move\tversions") {
        throw std::runtime_error("bad TSV header");
    }

    int cases = 0;
    int failures = 0;
    while (std::getline(input, line)) {
        if (line.empty()) {
            continue;
        }
        const Case item = parse_case(line);
        chess::Position pos;
        if (!pos.set_fen(item.fen)) {
            throw std::runtime_error("bad FEN for " + item.position_id);
        }
        const int reference = force_move_score(pos, item.reference_move, item.depth);
        const int alternate = force_move_score(pos, item.alternate_move, item.depth);
        const bool pass = reference == item.root_score && alternate == item.root_score;
        ++cases;
        failures += pass ? 0 : 1;
        std::cout << "depth=" << item.depth
                  << " position=" << item.position
                  << " position_id=" << item.position_id
                  << " versions=" << item.versions
                  << " root=" << item.root_score
                  << " reference_move=" << item.reference_move
                  << " reference_score=" << reference
                  << " alternate_move=" << item.alternate_move
                  << " alternate_score=" << alternate
                  << " status=" << (pass ? "verified_tie" : "fail") << '\n';
    }
    std::cout << "status=" << (failures == 0 ? "pass" : "fail")
              << " cases=" << cases << " failures=" << failures << '\n';
    return failures == 0 ? 0 : 2;
}
