#!/usr/bin/env python3
import argparse
import collections
import hashlib
import json
from pathlib import Path


VERSIONS = ("V15", "V19", "V23", "V25", "V27", "V29", "V30", "V35")


def load(path: Path):
    objects = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    metas = [obj for obj in objects if obj.get("type") == "meta"]
    summaries = [obj for obj in objects if obj.get("type") == "run_summary"]
    if len(metas) != 1 or tuple(metas[0].get("versions", ())) != VERSIONS:
        raise SystemExit(f"{path}: missing/invalid strict_milestones_v3 meta")
    if len(summaries) != 1 or summaries[0].get("status") != "pass":
        raise SystemExit(f"{path}: incomplete or failed run")
    corpus = {
        obj["position"]: (obj["position_id"], obj["fen"])
        for obj in objects if obj.get("type") == "corpus_position"
    }
    rows = [obj for obj in objects if obj.get("type") == "row"]
    expected = metas[0]["rounds_per_depth"] * metas[0]["legs_per_round"] * len(corpus) * len(VERSIONS)
    if len(rows) != expected or summaries[0].get("timed_rows") != expected:
        raise SystemExit(f"{path}: expected {expected} rows, got {len(rows)}")
    return corpus, rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", nargs="+", type=Path)
    parser.add_argument("--tsv", required=True, type=Path)
    parser.add_argument("--json", required=True, type=Path)
    args = parser.parse_args()

    cases = []
    differences = []
    depths_seen = set()
    corpus_hashes = set()
    input_hashes = {}
    for path in args.inputs:
        corpus, rows = load(path)
        input_hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
        corpus_hashes.update(row.get("corpus_hash") for row in [json.loads(path.read_text().splitlines()[0])])
        grouped = collections.defaultdict(lambda: collections.defaultdict(list))
        for row in rows:
            if not row.get("gate_pass"):
                raise SystemExit(f"{path}: row gate failed")
            depth = row["requested_depth"]
            depths_seen.add(depth)
            grouped[(depth, row["position"])][row["version"]].append(row)
        for (depth, position), by_version in sorted(grouped.items()):
            if set(by_version) != set(VERSIONS):
                raise SystemExit(f"{path}: incomplete versions at depth={depth} position={position}")
            canonical = {}
            for version, version_rows in by_version.items():
                moves = {row["move"] for row in version_rows}
                scores = {row["score"] for row in version_rows}
                nodes = {row["nodes"] for row in version_rows}
                if len(moves) != 1 or len(scores) != 1 or len(nodes) != 1:
                    raise SystemExit(f"{path}: nondeterministic {version} at depth={depth} position={position}")
                canonical[version] = (next(iter(moves)), next(iter(scores)))
            ref_move, ref_score = canonical["V15"]
            alternate_versions = collections.defaultdict(list)
            for version in VERSIONS[1:]:
                move, score = canonical[version]
                if score != ref_score:
                    raise SystemExit(f"{path}: score mismatch {version} at depth={depth} position={position}")
                if move != ref_move:
                    differences.append({
                        "depth": depth, "position": position, "position_id": corpus[position][0],
                        "version": version, "reference_move": ref_move, "alternate_move": move,
                        "root_score": ref_score,
                    })
                    alternate_versions[move].append(version)
            for alternate_move, versions in sorted(alternate_versions.items()):
                position_id, fen = corpus[position]
                cases.append({
                    "depth": depth, "position": position, "position_id": position_id, "fen": fen,
                    "root_score": ref_score, "reference_move": ref_move,
                    "alternate_move": alternate_move, "versions": versions,
                })

    if len(corpus_hashes) != 1:
        raise SystemExit(f"inconsistent corpus hashes: {corpus_hashes}")
    cases.sort(key=lambda x: (x["depth"], x["position"], x["alternate_move"]))
    differences.sort(key=lambda x: (x["depth"], x["position"], x["version"]))
    header = "depth\tposition\tposition_id\tfen\troot_score\treference_move\talternate_move\tversions\n"
    body = "".join(
        f'{case["depth"]}\t{case["position"]}\t{case["position_id"]}\t{case["fen"]}\t'
        f'{case["root_score"]}\t{case["reference_move"]}\t{case["alternate_move"]}\t'
        f'{",".join(case["versions"])}\n'
        for case in cases
    )
    args.tsv.write_text(header + body)
    report = {
        "benchmark": "strict_milestones_v3",
        "depths": sorted(depths_seen),
        "corpus_hash": next(iter(corpus_hashes)),
        "input_sha256": input_hashes,
        "difference_count_by_version": dict(collections.Counter(item["version"] for item in differences)),
        "version_position_differences": differences,
        "unique_forced_child_cases": cases,
    }
    args.json.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({
        "depths": report["depths"],
        "version_position_differences": len(differences),
        "unique_forced_child_cases": len(cases),
        "difference_count_by_version": report["difference_count_by_version"],
    }, sort_keys=True))


if __name__ == "__main__":
    main()
