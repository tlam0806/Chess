# Strict milestone benchmark: D6/D7/D8

Validation passed: 3,200 rows/depth, 400 samples/version, all correctness gates, the exact Williams order, slot/predecessor balance, and deterministic nodes were verified.

Elapsed ratio below 1.0 is faster. Brackets are the primary 95% paired complete-round bootstrap interval. Nodes and NPS are secondary diagnostics.

## Depth 6

| Version | Search time (s) | Time / V15 [95% CI] | Time / previous [95% CI] | Nodes | NPS | 2nd / 1st half time |
|---|---:|---:|---:|---:|---:|---:|
| V15 | 74.077 | 1.000 [1.000, 1.000] | — | 94,373,760 | 1,273,997 | 1.000 |
| V19 | 22.492 | 0.304 [0.303, 0.304] | 0.304 [0.303, 0.304] | 109,237,616 | 4,856,693 | 1.001 |
| V23 | 16.186 | 0.219 [0.218, 0.219] | 0.720 [0.719, 0.721] | 105,422,928 | 6,513,174 | 1.001 |
| V25 | 13.076 | 0.177 [0.176, 0.177] | 0.808 [0.807, 0.809] | 93,417,712 | 7,144,091 | 0.999 |
| V27 | 12.398 | 0.167 [0.167, 0.169] | 0.948 [0.944, 0.955] | 93,417,712 | 7,534,970 | 0.995 |
| V29 | 10.619 | 0.143 [0.143, 0.144] | 0.857 [0.852, 0.860] | 95,764,560 | 9,018,112 | 1.001 |
| V30 | 5.537 | 0.075 [0.075, 0.075] | 0.521 [0.519, 0.524] | 93,577,616 | 16,901,677 | 0.997 |
| V35 | 4.986 | 0.067 [0.067, 0.067] | 0.901 [0.898, 0.902] | 93,600,192 | 18,773,019 | 0.999 |

## Depth 7

| Version | Search time (s) | Time / V15 [95% CI] | Time / previous [95% CI] | Nodes | NPS | 2nd / 1st half time |
|---|---:|---:|---:|---:|---:|---:|
| V15 | 270.413 | 1.000 [1.000, 1.000] | — | 412,761,712 | 1,526,413 | 1.007 |
| V19 | 85.520 | 0.316 [0.315, 0.317] | 0.316 [0.315, 0.317] | 477,666,976 | 5,585,451 | 1.006 |
| V23 | 67.769 | 0.251 [0.250, 0.251] | 0.792 [0.791, 0.794] | 485,712,720 | 7,167,129 | 1.004 |
| V25 | 52.051 | 0.192 [0.192, 0.193] | 0.768 [0.767, 0.769] | 402,033,696 | 7,723,770 | 1.002 |
| V27 | 49.096 | 0.182 [0.181, 0.182] | 0.943 [0.941, 0.946] | 402,033,696 | 8,188,760 | 1.001 |
| V29 | 44.477 | 0.164 [0.164, 0.165] | 0.906 [0.903, 0.908] | 435,992,336 | 9,802,695 | 1.004 |
| V30 | 21.069 | 0.078 [0.078, 0.078] | 0.474 [0.473, 0.475] | 421,056,912 | 19,984,855 | 1.005 |
| V35 | 20.334 | 0.075 [0.075, 0.075] | 0.965 [0.964, 0.967] | 446,454,896 | 21,956,154 | 1.002 |

## Depth 8

| Version | Search time (s) | Time / V15 [95% CI] | Time / previous [95% CI] | Nodes | NPS | 2nd / 1st half time |
|---|---:|---:|---:|---:|---:|---:|
| V15 | 1540.075 | 1.000 [1.000, 1.000] | — | 1,783,448,240 | 1,158,027 | 1.008 |
| V19 | 399.923 | 0.260 [0.258, 0.261] | 0.260 [0.258, 0.261] | 1,680,385,616 | 4,201,775 | 1.004 |
| V23 | 311.096 | 0.202 [0.201, 0.203] | 0.778 [0.777, 0.779] | 1,858,582,992 | 5,974,303 | 1.006 |
| V25 | 240.714 | 0.156 [0.156, 0.157] | 0.774 [0.772, 0.776] | 1,490,775,632 | 6,193,142 | 1.001 |
| V27 | 228.003 | 0.148 [0.147, 0.149] | 0.947 [0.945, 0.950] | 1,490,775,632 | 6,538,395 | 1.003 |
| V29 | 187.195 | 0.122 [0.121, 0.122] | 0.821 [0.818, 0.824] | 1,485,084,576 | 7,933,365 | 1.004 |
| V30 | 98.304 | 0.064 [0.063, 0.064] | 0.525 [0.522, 0.528] | 1,419,505,360 | 14,439,922 | 1.002 |
| V35 | 87.155 | 0.057 [0.056, 0.057] | 0.887 [0.884, 0.890] | 1,446,177,216 | 16,593,126 | 1.001 |

## Interpretation limits

- Intervals describe timing variation in this one host run and fixed 25-position corpus; they are not Elo intervals or population-wide claims.
- Only eight complete rounds are available for the conservative round bootstrap, so its uncertainty estimate has limited resolution.
- Wall-clock search time can still reflect CPU frequency, thermals, and scheduler interference; this log contains no hardware-counter attribution.
- NPS is secondary because versions may visit different node counts even when they return the same fixed-depth score.
- Every tuple starts with a fresh 64 MiB searcher, TT, and history state, which is deliberately controlled but differs from a long-lived game process.
