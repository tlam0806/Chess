#include "move.hpp"
#include "position.hpp"
#include "search_types.hpp"
#include "searchers/strict/heuristic_searcher_v15.hpp"

#include <iostream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace {

struct Case {
    std::string_view id;
    std::string_view fen;
    int depth;
    int root_score;
    std::string_view reference_move;
    std::string_view alternate_move;
};

chess::Move find_move(const chess::Position& pos, std::string_view uci) {
    chess::MoveList moves;
    chess::generate_legal_moves(pos, moves);
    for (chess::Move move : moves) {
        if (chess::move_to_string(move) == uci) {
            return move;
        }
    }
    throw std::runtime_error("move is not legal: " + std::string(uci));
}

int parent_score_from_child(int child_score) {
    constexpr int MateThreshold = chess::CheckmateScore - 1024;
    if (child_score >= MateThreshold) {
        return -child_score + 1;
    }
    if (child_score <= -MateThreshold) {
        return -child_score - 1;
    }
    return -child_score;
}

int force_move_score(const chess::Position& root, std::string_view uci, int depth) {
    chess::Position child = root;
    child.make_move(find_move(root, uci));
    chess::HeuristicSearcherV15 searcher(64);
    const chess::SearchResult result = searcher.search_best_move(child, depth - 1);
    return parent_score_from_child(result.score);
}

} // namespace

int main() {
    const std::vector<Case> cases{
        {"closed_center_d4", "r1bq1rk1/pp1n1ppp/2pbpn2/3p4/3P4/2N1PN2/PPQ1BPPP/R1B2RK1 w - - 0 9", 4, -110, "c1d2", "e2d3"},
        {"closed_center_d7", "r1bq1rk1/pp1n1ppp/2pbpn2/3p4/3P4/2N1PN2/PPQ1BPPP/R1B2RK1 w - - 0 9", 7, -105, "c1d2", "e2d3"},
        {"opening_knights_d5", "rnb1kb1r/ppppqppp/5n2/4N3/4P3/8/PPPP1PPP/RNBQKB1R w KQkq - 1 4", 5, -20, "d2d4", "e5d3"},
        {"queenside_pressure_d5", "2r3k1/1p1bqppp/p3pn2/3p4/3P4/P1NBPN2/1PQ2PPP/2R2RK1 b - - 0 16", 5, -870, "d7c6", "e7d6"},
        {"queenside_pressure_d6", "2r3k1/1p1bqppp/p3pn2/3p4/3P4/P1NBPN2/1PQ2PPP/2R2RK1 b - - 0 16", 6, -880, "d7c6", "c8d8"},
        {"queenside_pressure_d7", "2r3k1/1p1bqppp/p3pn2/3p4/3P4/P1NBPN2/1PQ2PPP/2R2RK1 b - - 0 16", 7, -875, "d7c6", "e7d6"},
        {"tactical_castling_d1", "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8", 1, 530, "d7c8r", "d7c8q"},
        {"tactical_castling_d2", "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8", 2, 530, "d7c8r", "d7c8q"},
        {"tactical_castling_d3", "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8", 3, 530, "d7c8r", "d7c8q"},
        {"tactical_castling_d4", "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8", 4, 485, "d7c8r", "d7c8q"},
        {"tactical_castling_d5", "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8", 5, 535, "d7c8r", "d7c8q"},
        {"tactical_castling_d6", "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8", 6, 485, "d7c8r", "d7c8q"},
        {"tactical_castling_d7", "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8", 7, 530, "d7c8r", "d7c8q"},
        {"tactical_castling_d8", "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8", 8, 490, "d7c8r", "d7c8q"},
    };

    int failures = 0;
    for (const Case& item : cases) {
        chess::Position pos;
        if (!pos.set_fen(item.fen)) {
            throw std::runtime_error("bad FEN");
        }
        const int reference = force_move_score(pos, item.reference_move, item.depth);
        const int alternate = force_move_score(pos, item.alternate_move, item.depth);
        const bool pass = reference == item.root_score && alternate == item.root_score;
        failures += pass ? 0 : 1;
        std::cout << item.id << " root=" << item.root_score << " reference=" << reference
                  << " alternate=" << alternate << " status=" << (pass ? "verified_tie" : "fail")
                  << '\n';
    }
    std::cout << "status=" << (failures == 0 ? "pass" : "fail") << " failures=" << failures << '\n';
    return failures == 0 ? 0 : 2;
}
