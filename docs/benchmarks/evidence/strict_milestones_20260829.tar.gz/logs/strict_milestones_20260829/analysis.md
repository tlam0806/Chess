# Strict milestone benchmark: D6/D7/D8

Validation passed: 3,200 rows/depth, 400 samples/version, all correctness gates, the exact Williams order, slot/predecessor balance, and deterministic nodes were verified.

Elapsed ratio below 1.0 is faster. Brackets are the primary 95% paired complete-round bootstrap interval. Nodes and NPS are secondary diagnostics.

## Depth 6

| Version | Search time (s) | Time / V15 [95% CI] | Time / previous [95% CI] | Nodes | NPS | 2nd / 1st half time |
|---|---:|---:|---:|---:|---:|---:|
| V15 | 74.135 | 1.000 [1.000, 1.000] | — | 94,373,760 | 1,273,004 | 0.998 |
| V19 | 22.365 | 0.302 [0.301, 0.303] | 0.302 [0.301, 0.303] | 109,237,616 | 4,884,302 | 1.000 |
| V24 | 14.883 | 0.201 [0.200, 0.201] | 0.665 [0.665, 0.666] | 91,743,728 | 6,164,450 | 0.999 |
| V27 | 11.985 | 0.162 [0.161, 0.162] | 0.805 [0.803, 0.807] | 93,417,712 | 7,794,463 | 0.998 |
| V29 | 10.337 | 0.139 [0.139, 0.140] | 0.862 [0.861, 0.864] | 95,764,560 | 9,264,128 | 1.000 |
| V32 | 4.583 | 0.062 [0.062, 0.062] | 0.443 [0.442, 0.445] | 93,600,192 | 20,422,270 | 1.001 |
| V33 | 5.345 | 0.072 [0.072, 0.072] | 1.166 [1.161, 1.171] | 101,726,976 | 19,031,381 | 1.000 |
| V35 | 4.655 | 0.063 [0.062, 0.064] | 0.871 [0.857, 0.888] | 93,600,192 | 20,106,062 | 1.002 |

## Depth 7

| Version | Search time (s) | Time / V15 [95% CI] | Time / previous [95% CI] | Nodes | NPS | 2nd / 1st half time |
|---|---:|---:|---:|---:|---:|---:|
| V15 | 268.322 | 1.000 [1.000, 1.000] | — | 412,761,712 | 1,538,310 | 1.000 |
| V19 | 83.615 | 0.312 [0.311, 0.312] | 0.312 [0.311, 0.312] | 477,666,976 | 5,712,717 | 1.000 |
| V24 | 57.512 | 0.214 [0.214, 0.215] | 0.688 [0.687, 0.689] | 393,023,536 | 6,833,802 | 1.000 |
| V27 | 47.003 | 0.175 [0.175, 0.175] | 0.817 [0.816, 0.818] | 402,033,696 | 8,553,389 | 1.000 |
| V29 | 42.357 | 0.158 [0.158, 0.158] | 0.901 [0.900, 0.902] | 435,992,336 | 10,293,212 | 1.001 |
| V32 | 18.373 | 0.068 [0.068, 0.069] | 0.434 [0.433, 0.435] | 446,454,896 | 24,299,596 | 0.999 |
| V33 | 21.493 | 0.080 [0.080, 0.080] | 1.170 [1.168, 1.173] | 489,489,456 | 22,774,084 | 0.998 |
| V35 | 18.424 | 0.069 [0.069, 0.069] | 0.857 [0.856, 0.859] | 446,454,896 | 24,232,025 | 0.996 |

## Depth 8

| Version | Search time (s) | Time / V15 [95% CI] | Time / previous [95% CI] | Nodes | NPS | 2nd / 1st half time |
|---|---:|---:|---:|---:|---:|---:|
| V15 | 1432.457 | 1.000 [1.000, 1.000] | — | 1,783,448,240 | 1,245,027 | 1.045 |
| V19 | 381.343 | 0.266 [0.263, 0.268] | 0.266 [0.263, 0.268] | 1,680,385,616 | 4,406,491 | 1.032 |
| V24 | 283.130 | 0.198 [0.196, 0.199] | 0.742 [0.740, 0.746] | 1,644,548,368 | 5,808,461 | 1.037 |
| V27 | 211.203 | 0.147 [0.147, 0.148] | 0.746 [0.744, 0.750] | 1,490,775,632 | 7,058,497 | 1.043 |
| V29 | 173.972 | 0.121 [0.121, 0.122] | 0.824 [0.822, 0.825] | 1,485,084,576 | 8,536,329 | 1.043 |
| V32 | 77.932 | 0.054 [0.054, 0.055] | 0.448 [0.446, 0.451] | 1,446,177,216 | 18,557,029 | 1.049 |
| V33 | 89.952 | 0.063 [0.062, 0.063] | 1.154 [1.144, 1.160] | 1,631,739,056 | 18,140,143 | 1.039 |
| V35 | 78.296 | 0.055 [0.054, 0.055] | 0.870 [0.864, 0.881] | 1,446,177,216 | 18,470,720 | 1.054 |

## Interpretation limits

- Intervals describe timing variation in this one host run and fixed 25-position corpus; they are not Elo intervals or population-wide claims.
- Only eight complete rounds are available for the conservative round bootstrap, so its uncertainty estimate has limited resolution.
- Wall-clock search time can still reflect CPU frequency, thermals, and scheduler interference; this log contains no hardware-counter attribution.
- NPS is secondary because versions may visit different node counts even when they return the same fixed-depth score.
- Every tuple starts with a fresh 64 MiB searcher, TT, and history state, which is deliberately controlled but differs from a long-lived game process.
